Android ADB Commands Manual

https://adbshell.com